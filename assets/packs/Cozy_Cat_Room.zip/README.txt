Cozy Cat Room — Pixel Art Furniture & Decor Pack
=================================================

15 furniture pieces + 25 decorations (plus 2 animated props:
a sleeping cat and a twinkling star). PNG files at 5x scale, transparent
backgrounds.

Folders:
  furniture/            - sofa, chairs, table, shelf, curtains, rugs, etc.
  decorations/          - books, plants, cups, jars, photo frame, and more
  decorations/animated/ - sleeping cat (2 frames), twinkling star (6 frames)

-------------------------------------------------------------------------
LICENSE
-------------------------------------------------------------------------

You may:
  - Use these assets in your own projects, personal or commercial
    (including games you sell).
  - Modify them for your own use.

You may not:
  - Resell or redistribute these assets on their own — as a standalone
    asset pack, stock art bundle, etc. They must be used as part of a
    larger project, not sold/shared as raw assets.

Credit https://magewade.itch.io is appreciated but not required.

Made by magewade. Thanks for checking these out! 🐱
